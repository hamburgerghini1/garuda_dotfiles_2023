import{D as a,Z as i,_ as o}from"./index.dd23f9c8.js";var s=a(async({})=>{i()=="sabiiro"&&await o()});export{s as default};
