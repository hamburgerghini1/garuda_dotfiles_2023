import{k as a,c as e}from"./index.dd23f9c8.js";const s=a("div",{class:"q-space"});var p=e({name:"QSpace",setup(){return()=>s}});export{p as Q};
