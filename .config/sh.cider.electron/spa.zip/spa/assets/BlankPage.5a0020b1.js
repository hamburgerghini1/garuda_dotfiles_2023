import{Q as a}from"./QPage.0dd1bd55.js";import{aM as e,aC as r,aG as c}from"./index.dd23f9c8.js";const o={};function t(n,s){return r(),c(a)}var m=e(o,[["render",t]]);export{m as default};
