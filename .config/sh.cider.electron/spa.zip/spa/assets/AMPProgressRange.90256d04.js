import{r as p,I as s,dn as l,aC as i,aG as m}from"./index.dd23f9c8.js";const d={__name:"AMPProgressRange",props:{type:{type:String,default:"default"}},setup(r){const o=p(null),a=r;return s(()=>{const e=o.value.shadowRoot,t=document.createElement("style");console.log(a.type),a.type=="default"?t.textContent=`
    .time {
      font-family: var(--fontFamily);
    }
  `:t.textContent=`
    :host {
      margin:0px!important;
      display:block!important;
    }
    ::-webkit-slider-thumb {
      border-radius: 3px!important;
      width: 4px!important;
      display: var(--playerIndicator)!important;
    }
    .time {
      font-family: var(--fontFamily);
      display: none;
    }

    .scrubber input[type=range] {
      padding:0px!important;
    }
  `,t.textContent+=`
    .playback-progress {
      disabled: true;
    }
  `,e.appendChild(t)}),(e,t)=>{const n=l("amp-playback-controls-progress");return i(),m(n,{id:"amp-pbcp",theme:e.$q.dark.isActive?"dark":"light",ref_key:"progress",ref:o},null,8,["theme"])}}};export{d as _};
