import{F as a,c_ as r}from"./index.dd23f9c8.js";function u(){return a(r)}export{u};
